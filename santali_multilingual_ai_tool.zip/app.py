import gradio as gr
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, pipeline
import torch

# Load IndicTrans2 model
model_name = "ai4bharat/indictrans2-en-indic-1B"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
translator = pipeline("translation", model=model, tokenizer=tokenizer, device=0 if torch.cuda.is_available() else -1)

def translate_text(text, src_lang="en", tgt_lang="sat"):
    task_prefix = f"translate {src_lang} to {tgt_lang}: "
    inputs = tokenizer(task_prefix + text, return_tensors="pt", padding=True)
    outputs = model.generate(**inputs, max_length=512)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

# Gradio UI
with gr.Blocks() as demo:
    gr.Markdown("# 🌍 Santali Multilingual AI Tool")
    with gr.Row():
        inp = gr.Textbox(label="Input Text")
        src = gr.Dropdown(choices=["en", "hi", "sat", "bn", "ta", "te"], value="en", label="Source Language")
        tgt = gr.Dropdown(choices=["sat", "en", "hi", "bn", "ta", "te"], value="sat", label="Target Language")
    out = gr.Textbox(label="Translation Output")
    btn = gr.Button("Translate")
    btn.click(fn=translate_text, inputs=[inp, src, tgt], outputs=out)

if __name__ == "__main__":
    demo.launch()
