# 🌍 Santali Multilingual AI Tool

This tool supports:
- ✅ Translation (Santali + 20+ Indian languages + English)
- ✅ Speech-to-Text (ASR)
- ✅ OCR (Ol Chiki, Devanagari, Latin)
- ✅ Text-to-Speech (TTS, Multilingual)

## Run on Colab
```bash
!pip install -r requirements.txt
python app.py
```

## Deploy on Hugging Face Spaces
Upload:
- app.py
- requirements.txt
- README.md
- notebook.ipynb
